<?php
session_start();

$email = $_SESSION['email'];
$password = $_SESSION['password'];

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

   <!-- Bootstrap CSS -->
   <link rel="stylesheet" href="css/bootstrap.css">
  </head>

  <body>
    <nav class="navbar navbar-expand-lg fixed-top navbar-dark bg-dark">
  <button class="navbar-toggler p-0 border-0" type="button" data-toggle="offcanvas">
    <span class="navbar-toggler-icon"></span>
  </button>

<!-- BARRA SUPERIOR DE OPCIONES-->
  <div class="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
 </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Actividades</a>
        <div class="dropdown-menu" aria-labelledby="dropdown01">
          <a class="dropdown-item" href="Solicitar.php">Solicitar Certificado</a>
          <a class="dropdown-item" href="Visualizar.php">Visualizar Certificados</a>
        </div>
      </li>
    </ul>
    </div>

    <!-- ADMINISTRAR PERFIL-->
<label class="nav-item dropdown">
  <a class="nav-link dropdown-toggle mr-sm-4" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $email; ?><img class="mr-0" src="images/ibm.png" alt="" width="50" height="30"></a>
   <div class="dropdown-menu" aria-labelledby="dropdown01">
          <a class="dropdown-item" href="#">Perfil</a>
          <a class="dropdown-item" href="">Cerrar Sesión</a>
        </div>
</label></nav>

<br><br><br><br>

<section class="container">
<h1 class="h3 mb-3 font-weight-normal" align="center">Ingrese los datos para la solicitud</h1><br>

  <form action="guardar_solicitud.php" method="POST">

  <select class="form-control" name="universidad">
  <option>Seleccione la Universidad</option>
  <option>Universidad Adolfo Ibáñez</option>
  <option>Universidad del Desarrollo</option>
  <option>Pontificia Universidad Católica de Chile</option>
  <option>Universidad de Chile</option>
  <option>Universidad de Santiago de Chile</option>
</select>

<br><select class="form-control" name="tipo_de_certificado">
  <option>Seleccione el tipo de Certificado</option>
  <option>Diploma</option>
  <option>TOEFL</option>
</select>

<br> <div class="form-group">
  <input name="rut_alumno" class="form-control" placeholder="RUN (19.234.XXX-X)">
    </div>


<br><div class="form-group center" align="center">
<input class="btn btn-outline-success" type="Submit" name="enviar" value="Solicitar">
  </div>
  </form>
  </section>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="js/bootstrap.js"></script>
   
  </body>
</html>