

//$sql = "UPDATE users SET empresa = ".$empresa.", usuario = ".$usuario." , password = ".$password." WHERE usuario = ".$usuario;
//$UPDATE = mysql_query($Conectar, $sql);
//if (!$UPDATE) {
//	echo "hubo un error";
//}else{
//echo "<script type=\"text/javascript\">alert('Se ha modificado tu perfil exitosamente'); window.location='Inicio.php'</script>";
//} 

?>
<input type="text" name="Nombre" value="<?php echo $Nombre; ?>">
<input type="text" name="Nombre" value="<?php echo $Empresa; ?>">