<?php
require 'clases.php';
use usr\local\bin\Firebase\JWT\JWT;

?>